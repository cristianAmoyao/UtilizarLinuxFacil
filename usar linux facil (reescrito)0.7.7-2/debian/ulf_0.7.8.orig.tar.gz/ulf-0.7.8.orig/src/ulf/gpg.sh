gpg -c $
