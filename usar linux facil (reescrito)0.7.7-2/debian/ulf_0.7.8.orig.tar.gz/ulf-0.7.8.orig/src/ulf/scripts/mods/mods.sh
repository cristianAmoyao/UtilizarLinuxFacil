#! /bin/bash
echo "Bienvenido Al Instalador de mods"
IFS=“”
read -p  "Indique la ubicacion de la carpeta:  " opcion
echo " Se usar este comando mv $opcion $HOME/ulf "
echo "mv $opcion $HOME/ulf/scripts " > mods.sh
sh ./mods.sh
rm ./mods.sh

