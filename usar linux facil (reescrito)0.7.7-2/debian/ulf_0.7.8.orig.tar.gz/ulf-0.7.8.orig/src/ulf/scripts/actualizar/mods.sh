/home/cristian/Escritorio/ulf.gambas /usr/bin/
